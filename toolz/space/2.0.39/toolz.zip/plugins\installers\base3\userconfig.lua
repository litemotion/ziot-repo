WIFI_SSID = "Airtel"
WIFI_PWD  = "g21di6d1"
SERVER_DOMAIN="zctl-iot-server.eastasia.cloudapp.azure.com:8080"--"192.168.133.176:8080"
COUNTER_ON = true
ACCEL_ON =false
