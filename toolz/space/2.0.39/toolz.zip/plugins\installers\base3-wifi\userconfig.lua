WIFI_SSID = "DESKTOP-OD3EGR1 1300"
WIFI_PWD  = "litemotion!+SGVsbG8gUm91bnRlcg==,IEkgd2FudCB0byBkYXRlIHlvdS4="
SERVER_DOMAIN="zctl-iot-server.eastasia.cloudapp.azure.com:8080"--"192.168.133.176:8080"
COUNTER_ON = true
ACCEL_ON =false
