-- startup (for base v3) -- fixed for resend
node.flashindex("debug")()
node.flashindex("config")()
node.flashindex("timer")()
node.flashindex("store")()
node.flashindex("lighting")()
node.flashindex("network")()
node.flashindex("network2")()
node.flashindex("network3")()

debug.on()

if file.exists("no_resend.lua") then dofile("no_resend.lua") end  
if file.exists("fix_store_add.lua") then dofile("fix_store_add.lua") end

wifi.setmode(wifi.STATION)
led.start()
network.start()

if file.exists("wifi_conn.lua") then dofile("wifi_conn.lua") end

math.randomseed(tmr.now());math.random();
DEVICE_MESSAGE = encoder.toBase64(math.random()*301)..";"
DEVICE_MESSAGE = DEVICE_MESSAGE.."BASE03F3;DEVICE_PHYSICAL_ID:"..DEVICE_PHYSICAL_ID..";"

if ((COUNTER_ON == true) or (COUNTER_ON == nil))  then
  node.flashindex("counter")()
  if file.exists("counter.lua") then dofile("counter.lua") end  
  counter.start()
  DEVICE_MESSAGE = DEVICE_MESSAGE.."PIN_CIRCUIT_TYPE:"..counter.circult_type..";"
end 
if ACCEL_ON == true then
  DEVICE_MESSAGE = DEVICE_MESSAGE.."ACCEL:ON;"
  node.flashindex("accel")()
  if file.exists("accel_config.lua") then dofile("accel_config.lua") end  
  if ACCEL_ON == true then accel.start() end
end
DEVICE_MESSAGE = DEVICE_MESSAGE.."REASON:"..debug.reason()..";WIFI_SSID:"..WIFI_SSID
debug.print(DEVICE_MESSAGE)
