if(store) then
    store.add=function(t,s) end
end
debug.print("fix_store_add.lua loaded.")