wifi.eventmon.unregister(wifi.eventmon.STA_DISCONNECTED)

wifi.eventmon.register(wifi.eventmon.STA_DISCONNECTED,function(T)
  led.err()
  print("[wifi] STA_DISCONNECTED:","SSID:",T.SSID,"BSSID:",T.BSSID,"reason:",T.reason)
  print("[wifi] STA_DISCONNECTED: network.WS_OPENED:",network.WS_OPENED)
  if(network.ws) then network.ws:close() end
  network.WS_OPENED = false
  network.ws = nil
end)

network.idle  = 0
network.idleTs = 0

network.createWS = function() 
  debug.print('[network.createWS]')
  if network.ws == nil then 
    network.ws = websocket.createClient() 
    --ws = websocket.createClient()
    if not network.WS_OPENED then network.ws = websocket.createClient() end;
    
    network.ws:on("connection", function(ws)
      debug.print('[ws] on connection')
      network.WS_OPENED = true
      tmr.create():alarm(3100, tmr.ALARM_SINGLE, function() network.resend() end)
    end)

    network.ws:on("close", function(_, status)
      debug.print('[ws] connection closed, status:', status)
      -- conneciton timeout reboot the device
      if(status == -18) then  node.restart() end
      network.ws = nil -- required to Lua gc the websocket client
      network.WS_OPENED = false
      network.reconnectWS()
    end)


    network.output=function(str)
      network.temp = network.temp..'\n'..str
      if str =='> ' then
        local r = {res='input',data={output=network.temp}}
        local ok, s = pcall(sjson.encode,r)
        if(ok) then
          network.ws:send(s)
          network.temp = ''
          node.output(nil)
        end
      end
      
    end

    network.ws:on("receive", function(_, msg, opcode)
      if(opcode ~=1 ) then 
        debug.print("[ws][rec] opcode:",opcode)
        debug.print("msg type",type(msg),#msg)
        if file.open("upload-tmp", "a+") then
          file.write(msg)
          file.close()
          local r = '{"res":"upload","data":{"ok":true}}'
          network.ws:send(r);
        end

      else 
      -- original code
      debug.print('[ws][rec] message,opcode:', msg, opcode) -- opcode is 1 for text message, 2 for binary
      local t = sjson.decode(msg)
      if( t.req) then
        if(t.req == "auth") then
          timer.setTime(t.data.time)
          local r = {res="auth",data={id=DEVICE_ID,token=t.data.otp..DEVICE_TOKEN}}
          local ok, s = pcall(sjson.encode,r)
          if(ok) then 
            debug.print("[ws] json encoded:",s)
            network.ws:send(s)
          else debug.print("[ws][res:auth] fail to encode") end
        end
        if(t.req == "upload") then
          local fname = t.data.file
          local ftext = t.data.content
          local fd = file.open(fname,"w+")
          debug.print(fname)
          debug.print(ftext)
          fd:write(ftext)
          fd:close()  
          if file.exists(fname) then dofile(fname) end
          fd = nil
          local r = '{"res":"upload","data":{"ok":true}}'
          network.ws:send(r);
        end
        if(t.req =="file") then
          local fname = t.data.file
          local content = ""
          debug.print(fname)
          if file.open(fname) then
            content = file.read()
            file.close()
          end 
          local r = {res="file",data={ok=true,content=content}}
          local ok, s = pcall(sjson.encode,r)
          if(ok) then
            network.ws:send(s)
          else 
            network.ws:send('{"res="file","data":{"ok":false}}') 
          end
        end
        if(t.req=='dofile') then
          local fname = t.data.file
          if file.exists(fname) then 
            dofile(fname) 
            network.ws:send('{"res="dofile","data":{"ok":true}}') 
          else 
            network.ws:send('{"res="dofile","data":{"ok":false}}') 
          end
        end
        if(t.req=='remove') then
          local fname = t.data.file
          if file.exists(fname) then 
            file.remove(fname) 
            network.ws:send('{"res="remove","data":{"ok":true}}') 
          else 
            network.ws:send('{"res="dofile","data":{"ok":false,"error":"file not found"}}') 
          end
        end
        if(t.req=='input') then
          local cmd = t.data.command
          debug.print(cmd)
          node.input(cmd)
          node.output(network.output,1)
        end
      end

      if(t.res) then
        if t.res=="resend" then
          local ok,t = pcall(sjson.decode,msg)
          if ok then
            for k,v in pairs(t.data) do
              debug.print("remove:msg:",v)
              store.remove("msg",v)
            end
          else 
            debug.print("[ws][res:resend] fail to decode") 
      	  end
        end
        -- mid handling
        if t.res == "ack" then
          for i=#buffer, 1,-1 do
            if buffer[i].mid == t.mid then
              print(">>>>> ack:",t.mid)
              table.remove(buffer,i)
            end
          end
        end
      end
      end
      -- original code end

    end)

    network.ws:connect(network.endpoint)

  end;
  
  
end

network.reconnectWS=function()
  debug.print('[ws][reconnect..][endpoint]',network.endpoint)
  if(network.idleTs==0) then
    network.idleTs = tmr.now()
  else
    network.idle = network.idle + tmr.now() - network.idleTs
    network.idleTs = tmr.now()
  end
  debug.print(network.idleTs,network.idle)
  if(network.idle > 30* 1000000) then debug.print('[ws] idle over 30 sec, to restart'); node.restart() end

  if network.ws== nil then network.createWS()
  else
    network.ws:close()
    tmr.create():alarm(3000, tmr.ALARM_SINGLE, function()
      network.ws:connect(network.endpoint) 
    end)
  end
end

print("wifi_conn loaded")
