# TOOLZ README

 Visit the draft online document before running the program:
 
 http://zctl-iot-server.eastasia.cloudapp.azure.com:8080/download/toolz/doc/index.html
 
 or read the local copy located at  ./doc/index.html

 This program is still under development, many features have to be improved. 