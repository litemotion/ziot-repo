mid = 0
buffer = {}
tmr.create():alarm(3100, tmr.ALARM_SINGLE, function() 

  network.resend = function() end 

  network.sendCounter=function(type)
    local ip = wifi.sta.getip();
    local ts = timer.getTime();
    local data = {device_id=DEVICE_ID,ip=ip,ts=ts,type=type}
    --http
    if network.protocol == network.PROTOCOL_HTTP then
      local url = network.endpoint.."/counter/"..type.."/"..data.device_id.."/"..data.ts.."/"..data.ip
      http.get(url,nil,function(code,data)
          print(code,data)
          led.normal()
      end)
    end
    --ws
    if network.protocol == network.PROTOCOL_WS then
	    mid = mid +1
      local r = {event="counter",data=data,mid=mid}
      local ok, s = pcall(sjson.encode,r)
      if(ok) then 
        debug.print("[ws] json encoded:",s)
        table.insert(buffer,{mid=mid,m=s})
        if network.WS_OPENED then 
          if #buffer then
            for i,o in pairs(buffer) do
              network.ws:send(buffer[i].m)
            end
          end
			    --local e = network.ws:send(s)
	  	  end
        led.normal()
      else debug.print("[ws] event:counter fail to encode") 
      end
      data = nil
    end
  end

  wifi.eventmon.unregister(wifi.eventmon.STA_GOT_IP)
  wifi.eventmon.register(wifi.eventmon.STA_GOT_IP,function(T)
    led.normal()
    network.WIFI_GOT_IP_TS = tmr.now()
    debug.print("[wifi] STA_GOT_IP:",T.IP,T.netmask,T.gateway)
    network.WIFI_CONNECTED = true
    network.resolveEndpoint()
    network.createWS()
    network.WIFI_CONNECTING =false
    network.httpReqTime()
  end)

  if(network.ws) then
    network.ws:on("connection", function(ws)
      dbug.print('[ws] on connection')
      network.WS_OPENED = true
      tmr.create():alarm(3100, tmr.ALARM_SINGLE, function() network.sendHello() end)
    end)
    debug.print("network.ws on connection redefined.")
  end
  
  tmr.create():alarm(3000,tmr.ALARM_AUTO,function()
    if (wifi.sta.status() == wifi.STA_GOTIP) and (network.WS_OPENED) and network.ws then 
      if #buffer > 0  then
        --for i,o in pairs(buffer) do
          print(">>>> send by loop:",buffer[1].mid)
          network.ws:send(buffer[1].m)
        --end
      end
      --local e = network.ws:send(s)
    end
  end)


end)


debug.print("no_resend.lua loaded")
