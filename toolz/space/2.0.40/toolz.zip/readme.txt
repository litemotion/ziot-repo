# TOOLZ README

copyright(c) 2019 Simon CHAM and Lite Motion Company. All right reserved.

## Document

Visit the online document before running the program:
 
  https://www.litemotion.net/ziot-doc/zh-tw/toolz/
 
## Note

This program is still under development, many features have to be improved. 
