HDEF = {
  {
    pin=6,
    type='B',
    partition='L',
    buffer_interval = 20000, -- 20 sec
    buffer_count = 40,
    buffer_heap = 20000
  },
  {
    pin=7,
    type='B',
    partition='R',
    buffer_interval = 20000, -- 20 sec
    buffer_count = 40,
    buffer_heap = 20000
  }
}
print('_HDEF loaded')