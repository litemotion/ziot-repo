--node.setcpufreq(node.CPU160MHZ)

node.flashindex("dbug")()
node.flashindex("config")()
node.flashindex("timer")()
node.flashindex("lighting")()
node.flashindex("network")()
node.flashindex("handler")()
dbug.on()
led.start()
if file.exists('_WIFI.lua') then dofile('_WIFI.lua') end
if file.exists('_SOFTWD.lua') then dofile('_SOFTWD.lua') end
if file.exists('_HDEF.lua') then dofile('_HDEF.lua') end

if(SOFTWD) then tmr.softwd(SOFTWD) end 
wifi.setmode(wifi.STATION)
network.start()
if HDEF then  Handler.init(HDEF) end

math.randomseed(tmr.now());math.random();
DEVICE_MESSAGE = encoder.toBase64(math.random()*301)..";"
DEVICE_MESSAGE = DEVICE_MESSAGE.."BASE04.beta;DEVICE_PHYSICAL_ID:"..DEVICE_PHYSICAL_ID..";"
DEVICE_MESSAGE = DEVICE_MESSAGE.."REASON:"..dbug.reason()..";WIFI_SSID:"..WIFI_SSID
dbug.print('CPU frequency: '.. node.getcpufreq())
dbug.print(DEVICE_MESSAGE)
