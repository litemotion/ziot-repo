print('[time]:' .. tmr.now()/1000,'init.lua start')
if file.exists("userconfig.lua") then dofile("userconfig.lua") end
if file.exists("serverconfig.lua") then dofile("serverconfig.lua") end
if file.exists("_init.lua") then dofile("_init.lua") end
