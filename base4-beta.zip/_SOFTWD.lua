SOFTWD = 30*60 -- 30 min
print('_SOFTWD loaded')